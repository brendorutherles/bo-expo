import React, { useEffect, useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import Cadastro from "../screens/Cadastro";
import Login from "../screens/Login";
import Auth from '../services/auth';


const LoginStack = createStackNavigator();

const Logar = () => {

  return (
    <LoginStack.Navigator
      screenOptions={{
        headerShown: false,
      }}
    >
      <LoginStack.Screen name="Login" component={Login} />
      <LoginStack.Screen name="Cadastro" component={Cadastro} />
      <MainStack.Screen name='MainTabs' component={MainTabs} />
        <MainStack.Screen name='NewBO' component={NewBO} />
    </LoginStack.Navigator>
  );
};



export default () => {
  return (
    <NavigationContainer >
      <Logar />
    </NavigationContainer>
  );
};
